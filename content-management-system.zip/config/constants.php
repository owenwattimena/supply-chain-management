<?php

return [
    'order' => [
        'status' => ['draft', 'pending', 'proses', 'final', 'batal'],
    ],
    'access' => [
        'menu' => [
            'master' => ['developer', 'superadmin', 'admin', 'supplier'],
            'master_user' => ['developer', 'superadmin', 'admin'],
            'master_satuan' => ['developer', 'superadmin', 'admin'],
            'master_bahan_baku' => ['developer', 'superadmin', 'admin', 'supplier'],
            'persediaan' => ['developer', 'superadmin', 'admin', 'supplier'],
            'bahan_baku_masuk' => ['supplier'],
            'produksi' => ['produksi'],
            'pemesanan_bahan_baku' => [
                'access' => ['admin', 'superadmin', 'developer', 'supplier', 'stockpile'],
                'draft' => [
                    'tab' => ['admin', 'superadmin', 'developer'],
                    'tombol_tambah' => ['admin', 'superadmin', 'developer'],
                ],
                'pending' => [
                    'tab' => ['admin', 'superadmin', 'developer', 'supplier', 'stockpile'],
                ],
                'proses' => [
                    'tab' => ['admin', 'superadmin', 'developer', 'supplier', 'stockpile'],
                ],
                'diterima' => [
                    'tab' => ['admin', 'superadmin', 'developer', 'supplier', 'stockpile'],
                ],
                'dibatalkan' => [
                    'tab' => ['admin', 'superadmin', 'developer', 'supplier', 'stockpile'],
                ],
            ],
            'laporan' => ['developer', 'superadmin', 'admin'],
        ]
    ],
    'jenis_kelamin' => [
        'laki-laki' => 'Laki-laki',
        'perempuan' => 'Perempuan'
    ],
    'agama' => [
        'islam' => 'Islam',
        'kristen' => 'Kristen',
        'katolik' => 'Katolik',
        'hindu' => 'Hindu',
        'budah' => 'Budah',
        'konghucu' => 'Konghucu',
    ],
];
