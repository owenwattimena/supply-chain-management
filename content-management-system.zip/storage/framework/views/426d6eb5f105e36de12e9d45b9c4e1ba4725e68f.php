

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="content-header">
    <h1>
        Pengiriman Pasir
        <small>Pengiriman Pasir</small>
    </h1>
    <ol class="breadcrumb">
        <li><i class="fa fa-bars"></i> Pengiriman Pasir</li>
    </ol>
</section>
<section class="content">
    <div class="nav-tabs-custom">

        <ul class="nav nav-tabs ">
            <li class="active"><a href="#pengiriman" data-toggle="tab">Pengiriman</a></li>
            <li><a href="#diterima" data-toggle="tab">Diterima</a></li>
            
        </ul>
        <div class="tab-content">
            <div class="tab-pane active" id="pengiriman">
                <?php if(auth()->user()->role == 'supplier_pasir'): ?>
                <button class="btn bg-olive btn-flat" data-toggle="modal" data-target="#modal-default">Buat</button>

                <div class="modal fade" id="modal-default">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="<?php echo e(route('sand-delivery.create')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title">Pengiriman Pasir</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="nomor_kendaraan">Nomor Kendaraan</label>
                                        <input type="text" class="form-control" id="nomor_kendaraan" name="nomor_kendaraan" value="<?php echo e(old('nomor_kendaraan', '')); ?>" required placeholder="Masukan nomor kendaraan">
                                        <?php $__errorArgs = ['nomor_kendaraan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="nama_pengemudi">Nama Pengemudi</label>
                                        <input type="text" class="form-control" id="nama_pengemudi" name="nama_pengemudi" value="<?php echo e(old('nama_pengemudi', '')); ?>" required placeholder="Masukan Nama Pengemudi">
                                        <?php $__errorArgs = ['nama_pengemudi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="id_bahan_baku">Bahan Baku</label>
                                        <select type="text" class="form-control" id="id_bahan_baku" name="id_bahan_baku">
                                            <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option data-stok="<?php echo e($item->stokSupplier->stok); ?>" value="<?php echo e($item->id); ?>"><?php echo e($item->nama_bahan_baku); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_bahan_baku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="stok">Stok</label>
                                        <input disabled type="text" class="form-control" id="stok" name="stok" value="<?php echo e(old('stok', '')); ?>" required placeholder="Stok tersedia">
                                        <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="jumlah">Jumlah</label>
                                        <input type="text" class="form-control" id="jumlah" name="jumlah" value="<?php echo e(old('jumlah', '')); ?>" required placeholder="Masukan jumlah">
                                        <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default pull-left btn-flat" data-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary btn-flat">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <?php endif; ?>

                <div class="table-responsive">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <?php if(auth()->user()->role == 'stockpile'): ?>
                                <th></th>
                                <?php endif; ?>
                                <th>Tanggal</th>
                                <th>Nomor Kendaraan</th>
                                <th>Nama Pengemudi</th>
                                <th>Nomor</th>
                                <th>Bahan Baku</th>
                                
                                <th>Jumlah</th>
                                <th>Satuan</th>
                                <th>Harga</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0; ?>
                            
                            <?php $__currentLoopData = $pengiriman->where('status', 'pengiriman'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$no); ?></td>
                                <?php if(auth()->user()->role == 'stockpile'): ?>
                                <td> <a href="<?php echo e(route('sand-delivery.show', $item->id)); ?>" class="btn btn-success btn-flat btn-xs">Detail</a> </td>
                                <?php endif; ?>
                                <td><?php echo e($item->created_at); ?></td>
                                <td><?php echo e($item->nomor_kendaraan); ?></td>
                                <td><?php echo e($item->nama_pengemudi); ?></td>
                                <td><?php echo e($item->bahanBaku->nomor_bahan_baku); ?></td>
                                <td><?php echo e($item->bahanBaku->nama_bahan_baku); ?></td>
                                
                                <td><?php echo e($item->jumlah); ?></td>
                                <td><?php echo e($item->bahanBaku->satuan->satuan); ?></td>
                                <td> Rp. <?php echo e(number_format($item->bahanBaku->harga[0]->harga_jual)); ?></td>
                                <td> Rp. <?php echo e(number_format($item->jumlah * $item->bahanBaku->harga[0]->harga_jual)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="chart tab-pane" id="diterima" style="position: relative;">
                <div class="table-responsive">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <?php if(auth()->user()->role == 'stockpile' || auth()->user()->role == 'admin'): ?>
                                <th></th>
                                <?php endif; ?>
                                <th>Pengiriman</th>
                                <th>Penerimaan</th>
                                <th>Nomor Kendaraan</th>
                                <th>Nama Pengemudi</th>
                                <th>Nomor</th>
                                <th>Bahan Baku</th>
                                
                                <th>Jumlah</th>
                                <th>Satuan</th>
                                <th>Harga</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0; ?>
                            
                            <?php $__currentLoopData = $pengiriman->where('status', 'diterima'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$no); ?></td>
                                <?php if(auth()->user()->role == 'stockpile' || auth()->user()->role == 'admin'): ?>
                                <td> <a href="<?php echo e(route('sand-delivery.show', $item->id)); ?>" class="btn btn-success btn-flat btn-xs">Detail</a> </td>
                                <?php endif; ?>
                                <td><?php echo e($item->created_at); ?></td>
                                <td><?php echo e($item->tanggal_penerimaan); ?></td>
                                <td><?php echo e($item->nomor_kendaraan); ?></td>
                                <td><?php echo e($item->nama_pengemudi); ?></td>
                                <td><?php echo e($item->bahanBaku->nomor_bahan_baku); ?></td>
                                <td><?php echo e($item->bahanBaku->nama_bahan_baku); ?></td>
                                
                                <td><?php echo e($item->jumlah); ?></td>
                                <td><?php echo e($item->bahanBaku->satuan->satuan); ?></td>
                                <td> Rp. <?php echo e(number_format($item->bahanBaku->harga[0]->harga_jual)); ?></td>
                                <td> Rp. <?php echo e(number_format($item->jumlah * $item->bahanBaku->harga[0]->harga_jual)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    let stok = 0;

    $(function() {
        $('.table').DataTable()
        $('#example2').DataTable({
            'paging': true
            , 'lengthChange': false
            , 'searching': false
            , 'ordering': true
            , 'info': true
            , 'autoWidth': false
        })
    })

    function selectedStok() {
        var select = document.getElementById("id_bahan_baku");
        stok = parseInt(select.options[select.selectedIndex].dataset.stok);
        $('#stok').val(stok)
    }

    $(document).ready(function(){
        selectedStok()

        $('#id_bahan_baku').on('change', function() {
            selectedStok()
        })

        $('#jumlah').on('input', function() {
            var value = parseInt($(this).val());
            console.log(value)
            if (value > stok) {
                $(this).val(stok);
                return alert('Stok tidak cukup!')
            }
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\content-management-system\resources\views/admin/pengiriman-pasir/index.blade.php ENDPATH**/ ?>