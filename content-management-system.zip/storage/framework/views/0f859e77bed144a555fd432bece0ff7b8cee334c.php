

<?php echo $__env->make('admin.templates.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
    .badge {
        border-radius: 2px !important;
        font-size: 8pt;
    }

    .mb-0{
        margin-bottom: 0!important;
    }

</style>
<?php echo $__env->make('admin.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.templates.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    
    <?php if(session('status')): ?>
    <div class="alert alert-<?php echo session('status'); ?> alert-dismissible" style="border-radius: 0">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <p> <strong><?php echo session('type'); ?>.</strong> <?php echo session('message'); ?></p>
    </div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('body'); ?>
</div>
<!-- /.content-wrapper -->
<?php echo $__env->make('admin.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.templates.right-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin.templates.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH D:\laragon\www\content-management-system\resources\views/admin/templates/template.blade.php ENDPATH**/ ?>