
<?php /**PATH D:\laragon\www\content-management-system\resources\views/admin/templates/right-side.blade.php ENDPATH**/ ?>