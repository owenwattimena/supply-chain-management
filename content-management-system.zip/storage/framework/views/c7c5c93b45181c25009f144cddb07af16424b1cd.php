

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="content-header">
    <h1>
        Pemesanan Bahan Baku
        <small>Daftar pesanan bahan baku</small>
    </h1>
    <ol class="breadcrumb">
        <li><i class="fa fa-file-text"></i> Pemesanan Bahan Baku</li>
    </ol>
</section>
<section class="content">
    <div class="nav-tabs-custom">
        <?php $menunggu_total = count($order->where('status', 'menunggu')); ?>
        <?php $pending_total = count($order->where('status', 'pending')); ?>
        <?php $proses_total = count($order->where('status', 'proses')); ?>
        <ul class="nav nav-tabs">
            
            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.draft.tab', []) )): ?>
            <li class="active"><a href="#tab_1" data-toggle="tab">Draft</a></li>
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.menunggu.tab', []) )): ?>
            <li>
                <a href="#tab_menunggu" data-toggle="tab">
                    Menunggu Persetujuan
                    <?php if($menunggu_total > 0): ?>
                    <span class="badge bg-red" style="border-radius: 50px;"><?php echo e($menunggu_total); ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <?php endif; ?>
            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.pending.tab', []) )): ?>
            <li class="<?php echo e(( auth()->user()->role == 'supplier' || auth()->user()->role == 'stockpile') ? 'active' : ''); ?>">
                <a href="#tab_2" data-toggle="tab">
                    Pending
                    <?php if($pending_total > 0): ?>
                    <span class="badge bg-red" style="border-radius: 50px;"><?php echo e($pending_total); ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.proses.tab', []) )): ?>
            <li>
                <a href="#tab_3" data-toggle="tab">
                    Proses
                    <?php if($proses_total > 0): ?>
                    <span class="badge bg-blue" style="border-radius: 50px;"><?php echo e($proses_total); ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <?php endif; ?>
            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.diterima.tab', []) )): ?>
            <li><a href="#tab_4" data-toggle="tab">Diterima</a></li>
            <?php endif; ?>
            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.dibatalkan.tab', []) )): ?>
            <li><a href="#tab_5" data-toggle="tab">Dibatalkan</a></li>
            <?php endif; ?>
        </ul>
        <div class="tab-content">
            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.draft.tab', []) )): ?>
            <div class="tab-pane active" id="tab_1">
                <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.draft.tombol_tambah', []) )): ?>
                <button class="btn btn-flat bg-olive" style="margin-bottom: 15px" data-toggle="modal" data-target="#modal-default">TAMBAH</button>
                <div class="modal fade" id="modal-default">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form action="<?php echo e(route('order-raw-material.order')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title">Tambah Pemesanan Bahan Baku</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="nomor_pesanan">Nomor Pesanan</label>
                                        <input type="text" class="form-control" id="nomor_pesanan" name="nomor_pesanan" value="<?php echo e(old('nomor_pesanan', '')); ?>" required placeholder="Masukan nomor bahan baku">
                                        <?php $__errorArgs = ['nomor_pesanan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="id_supplier">Nama Supplier</label>
                                        <select class="form-control" id="id_supplier" name="id_supplier" required placeholder="Masukan nama bahan baku">
                                            <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['id_supplier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default pull-left btn-flat" data-dismiss="modal">Batal</button>
                                    <button type="submit" class="btn btn-primary btn-flat">Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nomor Pesanan</th>
                            <th>Nama Supplier</th>
                            <th>Dibuat Pada</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        ?>
                        <?php $__currentLoopData = $order->where('status', 'draft'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$no); ?></td>
                            <td><?php echo e($item->nomor_pesanan); ?></td>
                            <td><?php echo e($item->supplier->name); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('order-raw-material.show', $item->id)); ?>" class="btn btn-xs bg-green btn-flat">DETAIL</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>
            </div>
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.menunggu.tab', []) )): ?>
            <div class="tab-pane" id="tab_menunggu">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nomor Pesanan</th>
                            <th>Nama Supplier</th>
                            <th>Dibuat Pada</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        ?>
                        <?php $__currentLoopData = $order->where('status', 'menunggu'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$no); ?></td>
                            <td><?php echo e($item->nomor_pesanan); ?></td>
                            <td><?php echo e($item->supplier->name); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('order-raw-material.show', $item->id)); ?>" class="btn btn-xs bg-green btn-flat">DETAIL</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>
            </div>
            <?php endif; ?>
            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.pending.tab', []) )): ?>
            <div class="tab-pane <?php echo e(( auth()->user()->role == 'supplier' || auth()->user()->role == 'stockpile' ) ? 'active' : ''); ?>" id="tab_2">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nomor Pesanan</th>
                            <th>Nama Supplier</th>
                            <th>Dibuat Pada</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        ?>
                        <?php $__currentLoopData = $order->where('status', 'pending'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$no); ?></td>
                            <td><?php echo e($item->nomor_pesanan); ?></td>
                            <td><?php echo e($item->supplier->name); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('order-raw-material.show', $item->id)); ?>" class="btn btn-xs bg-green btn-flat">DETAIL</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>
            </div>
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.proses.tab', []) )): ?>
            <div class="tab-pane" id="tab_3">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nomor Pesanan</th>
                            <th>Nama Supplier</th>
                            <th>Dibuat Pada</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        ?>
                        <?php $__currentLoopData = $order->where('status', 'proses'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$no); ?></td>
                            <td><?php echo e($item->nomor_pesanan); ?></td>
                            <td><?php echo e($item->supplier->name); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('order-raw-material.show', $item->id)); ?>" class="btn btn-xs bg-green btn-flat">DETAIL</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    
                </table>
            </div>
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.diterima.tab', []) )): ?>
            <div class="tab-pane" id="tab_4">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nomor Pesanan</th>
                            <th>Nama Supplier</th>
                            <th>Dibuat Pada</th>
                            <th>Diterima Pada</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        ?>
                        <?php $__currentLoopData = $order->where('status', 'final'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$no); ?></td>
                            <td><?php echo e($item->nomor_pesanan); ?></td>
                            <td><?php echo e($item->supplier->name); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td><?php echo e($item->updated_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('order-raw-material.show', $item->id)); ?>" class="btn btn-xs bg-green btn-flat">DETAIL</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.dibatalkan.tab', []) )): ?>
            <div class="tab-pane" id="tab_5">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nomor Pesanan</th>
                            <th>Nama Supplier</th>
                            <th>Dibuat Pada</th>
                            <th>Dibatalkan Pada</th>
                            <th>Dibatalkan Oleh</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 0;
                        ?>
                        <?php $__currentLoopData = $order->where('status', 'batal'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$no); ?></td>
                            <td><?php echo e($item->nomor_pesanan); ?></td>
                            <td><?php echo e($item->supplier->name); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td><?php echo e($item->updated_at); ?></td>
                            <td><?php echo e($item->cancelBy->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('order-raw-material.show', $item->id)); ?>" class="btn btn-xs bg-green btn-flat">DETAIL</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>

</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $(function() {
        $('.table').DataTable()
        $('#example2').DataTable({
            'paging': true
            , 'lengthChange': false
            , 'searching': false
            , 'ordering': true
            , 'info': true
            , 'autoWidth': false
        })
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\content-management-system\resources\views/admin/pemesanan-bahan-baku/index.blade.php ENDPATH**/ ?>