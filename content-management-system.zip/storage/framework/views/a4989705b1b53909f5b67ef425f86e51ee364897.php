<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="info" style="position: static; text-align: center">
                
                <p class="mb-0"><i class=""></i> <?php echo e(auth()->user()->name); ?></p>
                
                <!-- Status -->
                
            </div>
        </div>

        <!-- search form (Optional) -->
        
        <!-- /.search form -->

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header">MENU UTAMA</li>
            <li class="<?php echo e((request()->is('dashboard*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-tachometer"></i> <span>Dashboard</span></a></li>
            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.master', []) )): ?>
            <li class="<?php echo e((request()->is('master*')) ? 'active' : ''); ?> treeview menu-open">
                <a href="#">
                    <i class="fa fa-th"></i> <span>Master</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.master_user', []) )): ?>
                    <li class="<?php echo e((request()->is('master/user*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('master.user')); ?>"><i class="fa fa-user-secret"></i> Pengguna</a></li>
                    <?php endif; ?>
                    <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.master_satuan', []) )): ?>
                    <li class="<?php echo e((request()->is('master/satuan*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('master.unit')); ?>"><i class="fa fa-circle"></i> Satuan</a></li>
                    <?php endif; ?>
                    <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.master_bahan_baku', []) )): ?>
                    <li class="<?php echo e((request()->is('master/bahan-baku*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('master.raw-material')); ?>"><i class="fa fa-archive"></i> Bahan Baku</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.persediaan', []) )): ?>
            <li class="<?php echo e((request()->is('persediaan*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('stock')); ?>"><i class="fa fa-bars"></i> <span>Persediaan</span></a></li>
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.bahan_baku_masuk', []) )): ?>
            <li class="<?php echo e((request()->is('transaksi-bahan-baku*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('incoming-raw-material')); ?>"><i class="fa fa-file-text"></i> <span>Transaksi Bahan Baku </span></a></li>
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.pemesanan_bahan_baku.access', []) )): ?>
            <li class="<?php echo e((request()->is('pemesanan-bahan-baku*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('order-raw-material')); ?>"><i class="fa fa-file-text"></i> <span>Pesanan Bahan Baku</span></a></li>
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.produksi', []) )): ?>
            <li class="<?php echo e((request()->is('produksi*')) ? 'active' : ''); ?> treeview menu-open">
                <a href="#">
                    <i class="fa fa-archive"></i> <span>Produksi</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.produksi', []) )): ?>
                    <li class="<?php echo e((request()->is('produksi/produk')) ? 'active' : ''); ?>"><a href="<?php echo e(route('production.product')); ?>"><i class="fa fa-cube"></i> Produk</a></li>
                    <?php endif; ?>
                    <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.produksi', []) )): ?>
                    <li class="<?php echo e((request()->is('produksi/pekerja*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('production.worker')); ?>"><i class="fa fa-users"></i> Pekerja</a></li>
                    <?php endif; ?>
                    <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.produksi', []) )): ?>
                    <li class="<?php echo e((request()->is('produksi/produksi*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('production')); ?>"><i class="fa fa-archive"></i> Produksi</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            
            <?php endif; ?>

            <?php if(in_array(auth()->user()->role, Config::get('constants.access.menu.laporan', []) )): ?>
            <li class="treeview menu-open <?php echo e((request()->is('laporan*')) ? 'active' : ''); ?>">
                <a href="#">
                    <i class="fa fa-file-excel-o"></i> <span>Laporan</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li class="<?php echo e((request()->is('laporan/produksi*')) ? 'active' : ''); ?>"><a href="<?php echo e(route('report.production')); ?>"><i class="fa fa-cube"></i> Produksi</a></li>
                </ul>
            </li>
            <?php endif; ?>
        </ul>
        <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH D:\laragon\www\content-management-system\resources\views/admin/templates/aside.blade.php ENDPATH**/ ?>