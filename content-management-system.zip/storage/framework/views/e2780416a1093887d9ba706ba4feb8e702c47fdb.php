

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="content-header">
    <h1>
        Penerimaan Pasir
        <small>penerimaan Pasir</small>
    </h1>
    <ol class="breadcrumb">
        <li><i class="fa fa-bars"></i> penerimaan Pasir</li>
    </ol>
</section>
<section class="content">
    <div class="nav-tabs-custom">

        <ul class="nav nav-tabs ">
            <li class="active"><a href="#penerimaan" data-toggle="tab">penerimaan</a></li>
            <li><a href="#diterima" data-toggle="tab">Diterima</a></li>
            <li><a href="#dibatalkan" data-toggle="tab">Dibatalkan</a></li>
        </ul>
        <div class="tab-content">
            <div class="tab-pane active" id="penerimaan">
                

                <div class="table-responsive">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Tanggal</th>
                                <th>Nomor Kendaraan</th>
                                <th>Nama Pengemudi</th>
                                <th>Nomor</th>
                                <th>Bahan Baku</th>
                                
                                <th>Jumlah</th>
                                <th>Satuan</th>
                                <th>Harga</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0; ?>
                            
                            <?php $__currentLoopData = []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$no); ?></td>
                                <td><?php echo e($item->created_at); ?></td>
                                <td><?php echo e($item->nomor_kendaraan); ?></td>
                                <td><?php echo e($item->nama_pengemudi); ?></td>
                                <td><?php echo e($item->bahanBaku->nomor_bahan_baku); ?></td>
                                <td><?php echo e($item->bahanBaku->nama_bahan_baku); ?></td>
                                
                                <td><?php echo e($item->jumlah); ?></td>
                                <td><?php echo e($item->bahanBaku->satuan->satuan); ?></td>
                                <td> Rp. <?php echo e(number_format($item->bahanBaku->harga[0]->harga_jual)); ?></td>
                                <td> Rp. <?php echo e(number_format($item->jumlah * $item->bahanBaku->harga[0]->harga_jual)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="chart tab-pane" id="diterima" style="position: relative;"></div>
            <div class="chart tab-pane" id="dibatalkan" style="position: relative;"></div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    let stok = 0;

    $(function() {
        $('#example1').DataTable()
        $('#example2').DataTable({
            'paging': true
            , 'lengthChange': false
            , 'searching': false
            , 'ordering': true
            , 'info': true
            , 'autoWidth': false
        })
    })

    function selectedStok() {
        var select = document.getElementById("id_bahan_baku");
        stok = parseInt(select.options[select.selectedIndex].dataset.stok);
        $('#stok').val(stok)
    }

    $(document).ready(function(){
        selectedStok()

        $('#id_bahan_baku').on('change', function() {
            selectedStok()
        })

        $('#jumlah').on('input', function() {
            var value = parseInt($(this).val());
            console.log(value)
            if (value > stok) {
                $(this).val(stok);
                return alert('Stok tidak cukup!')
            }
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\content-management-system\resources\views/admin/penerimaan-pasir/index.blade.php ENDPATH**/ ?>