

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="content-header">
    <h1>
        Bahan Baku
        <small>Daftar bahan baku</small>
    </h1>
    <ol class="breadcrumb">
        <li><i class="fa fa-users"></i> Bahan Baku</li>
    </ol>
</section>
<section class="content">
    <div class="box box-default">
        <div class="box-header with-border">
            <h3 class="box-title">Bahan Baku</h3>
        </div>
        <div class="box-body">
            <?php if(auth()->user()->role == 'supplier'): ?>
                
            <button class="btn btn-flat bg-olive" style="margin-bottom: 15px" data-toggle="modal" data-target="#modal-default">TAMBAH</button>
            <div class="modal fade" id="modal-default">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="<?php echo e(route('master.raw-material.post')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title">Tambah Bahan Baku</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="nomor_bahan_baku">Nomor Bahan Baku</label>
                                    <input type="text" class="form-control" id="nomor_bahan_baku" name="nomor_bahan_baku" value="<?php echo e(old('nomor_bahan_baku', '')); ?>" required placeholder="Masukan nomor bahan baku">
                                    <?php $__errorArgs = ['nomor_bahan_baku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="nama_bahan_baku">Nama Bahan Baku</label>
                                    <input type="text" class="form-control" id="nama_bahan_baku" name="nama_bahan_baku" value="<?php echo e(old('nama_bahan_baku', '')); ?>" required placeholder="Masukan nama bahan baku">
                                    <?php $__errorArgs = ['nama_bahan_baku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="spesifikasi">Spesifikasi</label>
                                    <textarea class="form-control" id="spesifikasi" name="spesifikasi" required placeholder="Spesifikasi"><?php echo e(old('spesifikasi', '')); ?></textarea>
                                    <?php $__errorArgs = ['spesifikasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="help-block"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label>Satuan</label>
                                    <select class="form-control" name="id_satuan">
                                        <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->satuan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default pull-left btn-flat" data-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary btn-flat">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nomor Bahan Baku</th>
                        <th>Nama Bahan Baku</th>
                        <th>Spesifikasi</th>
                        <th>Satuan</th>
                        <th>Harga</th>
                        <th>Supplier</th>
                        <?php if(auth()->user()->role == 'supplier'): ?>
                        <th></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 0;
                    ?>
                    <?php $__currentLoopData = $bahanBaku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$no); ?></td>
                        <td><?php echo e($item->nomor_bahan_baku); ?></td>
                        <td><?php echo e($item->nama_bahan_baku); ?></td>
                        <td><?php echo e($item->spesifikasi); ?></td>
                        <td><?php echo e($item->satuan->satuan); ?></td>
                        <?php $_harga = $item->harga->where('status', true)->first(); ?>
                        <td><?php echo e($_harga ?'Rp. ' . number_format($_harga->harga_jual, 0, ',', '.') : ''); ?></td>
                        <?php if(auth()->user()->role != 'supplier'): ?>
                        <td><?php echo e($item->supplier->name); ?></td>
                        <?php endif; ?>
                        <?php if(auth()->user()->role == 'supplier'): ?>
                        <td>
                            <button class="btn btn-xs bg-green btn-flat" data-toggle="modal" data-target="#modal-harga-<?php echo e($item->id); ?>">HARGA</button>
                            <button class="btn btn-xs bg-orange btn-flat" data-toggle="modal" data-target="#modal-<?php echo e($item->id); ?>">UBAH</button>
                            <form action="<?php echo e(route('master.raw-material.delete', $item->id)); ?>" method="post" style="display: inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button type="submit" onclick="return confirm('Yakin ingin menghapus bahan baku?')" class="btn btn-xs bg-maroon btn-flat">HAPUS</butt>
                            </form>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php if(auth()->user()->role == 'supplier'): ?>
                    <div class="modal fade" id="modal-harga-<?php echo e($item->id); ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title">Harga Bahan Baku</h4>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('master.raw-material.price', $item->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <label for="harga">Harga</label>
                                        <div class="input-group input-group">
                                            <input type="number" class="form-control" name="harga" id="harga" required>
                                            <span class="input-group-btn">
                                                <button type="submit" class="btn btn-info btn-flat">Tambah</button>
                                            </span>
                                        </div>
                                        <?php $__errorArgs = ['harga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="help-block"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </form>
                                    <ul class="list-group list-group-unbordered">
                                        <li class="list-group-item">
                                            <b># Harga <span class="pull-right">Tanggal</span></b>
                                        </li>
                                        <?php
                                            $_no = 0 ;
                                        ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $item->harga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $harga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <li class="list-group-item">
                                            <?php echo e(++$_no); ?>.  Rp. <?php echo e(number_format( $harga->harga_jual,0,",","." )); ?> <span class="pull-right"><?php echo e($harga->created_at); ?></span>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <li>Tidak ada data.</li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default pull-left btn-flat" data-dismiss="modal">Batal</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="modal-<?php echo e($item->id); ?>">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="<?php echo e(route('master.raw-material.put', $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Ubah Bahan Baku</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="nomor_bahan_baku">Nomor Bahan Baku</label>
                                            <input type="text" class="form-control" id="nomor_bahan_baku" name="nomor_bahan_baku" value="<?php echo e(old('nomor_bahan_baku', $item->nomor_bahan_baku)); ?>" required placeholder="Masukan nomor bahan baku">
                                            <?php $__errorArgs = ['nomor_bahan_baku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="help-block"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="nama_bahan_baku">Nama Bahan Baku</label>
                                            <input type="text" class="form-control" id="nama_bahan_baku" name="nama_bahan_baku" value="<?php echo e(old('nama_bahan_baku', $item->nama_bahan_baku)); ?>" required placeholder="Masukan nama bahan baku">
                                            <?php $__errorArgs = ['nama_bahan_baku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="help-block"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="spesifikasi">Spesifikasi</label>
                                            <textarea class="form-control" id="spesifikasi" name="spesifikasi" required placeholder="Spesifikasi"><?php echo e(old('spesifikasi', $item->spesifikasi)); ?></textarea>
                                            <?php $__errorArgs = ['spesifikasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="help-block"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label>Satuan</label>
                                            <select class="form-control" name="id_satuan">
                                                <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php echo e($val->id == $item->satuan->id ? 'selected' : ''); ?> value="<?php echo e($val->id); ?>"><?php echo e($val->satuan); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default pull-left btn-flat" data-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-primary btn-flat">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>  
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Nomor Bahan Baku</th>
                        <th>Nama Bahan Baku</th>
                        <th>Spesifikasi</th>
                        <th>Satuan</th>
                        <th>Harga</th>
                        <?php if(auth()->user()->role != 'supplier'): ?>
                        <th>Supplier</th>
                        <?php endif; ?>
                        <?php if(auth()->user()->role == 'supplier'): ?>
                        <th></th>
                        <?php endif; ?>
                    </tr>
                </tfoot>
            </table>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $(function() {
        $('#example1').DataTable()
        $('#example2').DataTable({
            'paging': true
            , 'lengthChange': false
            , 'searching': false
            , 'ordering': true
            , 'info': true
            , 'autoWidth': false
        })
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\content-management-system\resources\views/admin/bahan-baku/index.blade.php ENDPATH**/ ?>