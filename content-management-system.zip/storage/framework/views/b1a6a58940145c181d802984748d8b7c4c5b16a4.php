<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laporan Penerimaan Pasir</title>
    <style>
        .header {
            position: relative;
            width: 100%;
            border: 2px solid orange;
            height: 55px;
            margin-bottom: 55px;
        }

        .header .title {
            position: absolute;
            width: 59.5%;
            background: orange;
            display: inline-block;
            height: 55px;
        }

        .header .logo {
            position: absolute;
            left: 59.5%;
            height: 55px;
            width: 38.5%;
            display: inline-block;
            text-align: center;
        }

        .header h1 {
            font-size: 16pt;
            text-align: center;
        }

        .logo img {
            margin-top: 8px;
            height: 40px;
        }

        .info {
            margin-top: 10px;
            margin-bottom: 10px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid black;
            font-size: 10pt;
        }

        .table tr,
        .table th,
        .table td {
            border: 1px solid black;

        }

        .footer {
            width: 100%;
            /* text-align: center; */
            position: fixed;
            bottom: 0px;
            font-size: 10pt;
        }

        .pagenum:before {
            content: counter(page);
        }

        .float-right {
            float: right;
        }

        .text-right {
            text-align: right;
        }

    </style>
</head>
<body>
    <div class="header">
        <div class="title">
            <h1>LAPORAN PENERIMAAN PASIR</h1>
        </div>
        <div class="logo">
            <img src="<?php echo e(asset('assets/images/wamin.png')); ?>" alt="logo-wamin">
        </div>
    </div>
    <table class="info">
        <tr>
            <td style="widtd:50%">Tanggal</td>
            <td> : <?php echo e(date_format(date_create($from), 'Y-m-d')); ?> s/d <?php echo e(date_format(date_create($to), 'Y-m-d')); ?></td>
        </tr>
    </table>
    <table id="example1" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th>Pengiriman</th>
                <th>Penerimaan</th>
                <th>Nomor Kendaraan</th>
                <th>Nama Pengemudi</th>
                <th>Nomor</th>
                <th>Bahan Baku</th>
                <th>Jumlah</th>
                <th>Satuan</th>
                <th>Harga</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 0; ?>
            <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e(++$no); ?></td>
                <td><?php echo e($item->created_at); ?></td>
                <td><?php echo e($item->tanggal_penerimaan); ?></td>
                <td><?php echo e($item->nomor_kendaraan); ?></td>
                <td><?php echo e($item->nama_pengemudi); ?></td>
                <td><?php echo e($item->bahanBaku->nomor_bahan_baku); ?></td>
                <td><?php echo e($item->bahanBaku->nama_bahan_baku); ?></td>
                <td><?php echo e($item->jumlah); ?></td>
                <td><?php echo e($item->bahanBaku->satuan->satuan); ?></td>
                <td> Rp. <?php echo e(number_format($item->bahanBaku->harga[0]->harga_jual)); ?></td>
                <td> Rp. <?php echo e(number_format($item->jumlah * $item->bahanBaku->harga[0]->harga_jual)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="footer">
        Supply Chain Management System - Production Report <span class="float-right">Hal. <span class="pagenum"></span></span>
    </div>
</body>
</html>
<?php /**PATH D:\laragon\www\content-management-system\resources\views/admin/laporan/unduh-pengiriman-pasir.blade.php ENDPATH**/ ?>