

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="content-header">
    <h1>
        Detail Produksi
        <small>Detail Produksi</small>
    </h1>
    <ol class="breadcrumb">
        <li><i class="fa fa-users"></i> Detail Produksi</li>
    </ol>
</section>
<section class="content">
    <?php if($produksi->status != 'final'): ?>
    <div class="text-right margin">
        <button class="btn btn-primary btn-flat" data-toggle="modal" data-target="#final-modal">FINAL</button>
    </div>
    <div class="modal fade" id="final-modal">
        <div class="modal-dialog">
            <form action="<?php echo e(route('production.final', $produksi->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Finalkan Produksi</h4>
                    </div>
                    <div class="modal-body">
                        <p class="text-red">Masukan Produk dan Jumlah Produk yang di hasilkan</p>
                        <div class="form-group">
                            <label for="produk">Produk</label>
                            <select class="form-control" id="produk" name="id_produk" required>
                                <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?> - <?php echo e($item->satuan->satuan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['id_produk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="jumlah_produksi">_produksi</label>
                            <input type="number" class="form-control" id="jumlah_produksi" name="jumlah" value="<?php echo e(old('jumlah', '')); ?>" required placeholder="Jumlah">
                            <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="help-block"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="reset" class="btn btn-default pull-left" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">FINAL</button>
                    </div>
                </div>
            </form>

        </div>

    </div>
    
    <?php endif; ?>
    <div class="row" style="clear: both">
        <div class="col-md-8">
            <div class="box box-default">
                <div class="box-header with-border">
                    <h3 class="box-title">Produksi</h3>
                </div>
                <div class="box-body">

                    <div class="table-responsive" style="clear: both">
                        <table class="table">
                            <tr>
                                <th style="width:50%">Tanggal:</th>
                                <td><?php echo e($produksi->tanggal_mulai); ?></td>
                            </tr>
                            <tr>
                                <th style="width:50%">Jam Mulai:</th>
                                <td><?php echo e($produksi->jam_mulai); ?></td>
                            </tr>
                            
                            <tr>
                                <th style="width:50%">Jam Selesai:</th>
                                <td><?php echo e($produksi->jam_selesai); ?></td>
                            </tr>
                            <?php if($produksi->id_produk != null): ?>
                            <tr>
                                <th style="width:50%">Produk:</th>
                                <td><?php echo e($produksi->produk->nama); ?></td>
                            </tr>
                            <tr>
                                <th style="width:50%">Jumlah:</th>
                                <td><?php echo e($produksi->jumlah); ?> <?php echo e($produksi->produk->satuan->satuan); ?></td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                    <hr>
                    <?php if($produksi->status != 'final'): ?>
                    <button class="btn btn-flat bg-olive" style="margin-bottom: 15px" data-toggle="modal" data-target="#modal-default">TAMBAH</button>
                    <div class="modal fade" id="modal-default">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form id="form-order" action="<?php echo e(route('production.detail.create', $produksi->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title">Tambah Bahan Baku Produksi</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="select-bahan-baku">Bahan Baku</label>
                                            <select class="form-control" id="select-bahan-baku" name="id_bahan_baku" required>
                                                <?php $__currentLoopData = $bahanBaku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-stok="<?php echo e($item->stokPersediaan->stok ?? 0); ?>" value="<?php echo e($item->id); ?>"><?php echo e($item->nama_bahan_baku); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php $__errorArgs = ['bahan_baku'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="help-block"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="stok">Stok Bahan Baku</label>
                                            <input type="number" disabled class="form-control" id="stok" name="stok" required placeholder="stok">
                                            <?php $__errorArgs = ['stok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="help-block"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="jumlah">Jumlah</label>
                                            <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?php echo e(old('jumlah', '')); ?>" required placeholder="Jumlah">
                                            <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="help-block"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default pull-left btn-flat" data-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-primary btn-flat">Simpan</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nomor Bahan Baku</th>
                                <th>Nama Bahan Baku</th>
                                <th>Jumlah</th>
                                <th>Satuan</th>
                                <?php if($produksi->status != 'final'): ?>
                                <th></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 0;
                            ?>
                            <?php $__currentLoopData = $produksi->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$no); ?></td>
                                <td><?php echo e($item->bahanBaku->nomor_bahan_baku); ?></td>
                                <td><?php echo e($item->bahanBaku->nama_bahan_baku); ?></td>
                                <td><?php echo e($item->jumlah); ?></td>
                                <td><?php echo e($item->bahanBaku->satuan->satuan); ?></td>
                                <?php if($produksi->status != 'final'): ?>

                                <td>
                                    
                                    <form action="<?php echo e(route('production.detail.delete', [ $produksi->id, $item->id])); ?>" method="post" style="display: inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" onclick="return confirm('Yakin ingin menghapus bahan baku?')" class="btn btn-xs bg-maroon btn-flat">HAPUS</butt>
                                    </form>
                                </td>
                                
                <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>#</th>
                        <th>Nomor Bahan Baku</th>
                        <th>Nama Bahan Baku</th>
                        <th>Jumlah</th>
                        <th>Satuan</th>
                        <?php if($produksi->status != 'final'): ?>
                        <th></th>
                        <?php endif; ?>
                    </tr>
                </tfoot>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="box box-default">
            <div class="box-header with-border">
                <h3 class="box-title">Kehadiran</h3>
            </div>
            <div class="box-body">
                <div class="form-group">
                    <?php if($produksi->status != 'final'): ?>
                    <form action="<?php echo e(route('production.kehadiran', $produksi->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php $__currentLoopData = $pekerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label>
                            <input type="checkbox" name="kehadiran[]" value=" <?php echo e($item->id); ?>" class="flat-red" <?php echo e(isset($item->kehadiran[0]) ? ($item->kehadiran[0]->status_kehadiran ? 'checked' : '') : ''); ?>>
                            <?php echo e($item->nama); ?>

                        </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button class="btn btn-sm btn-primary btn-flat btn-block" type="submit" style="margin-top: 15px">SIMPAN</button>
                    </form>
                    <?php else: ?>
                    <ul>

                        <?php $__currentLoopData = $produksi->kehadiran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($val->pekerja->nama); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    </div>

</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $(function() {
        $('#example1').DataTable()
        $('#example2').DataTable({
            'paging': true
            , 'lengthChange': false
            , 'searching': false
            , 'ordering': true
            , 'info': true
            , 'autoWidth': false
        })
    })

    function selectedStok() {
        var select = document.getElementById("select-bahan-baku");
        stok = parseInt(select.options[select.selectedIndex].dataset.stok);
        $('#stok').val(stok)
    }

    $(document).ready(function() {
        selectedStok();

        $('#select-bahan-baku').on('change', function() {
            selectedStok()
        })

        $('#jumlah').on('input', function() {
            var value = parseInt($(this).val());
            if (value > stok) {
                $(this).val(stok);
                return alert('Stok tidak cukup!')
            }
        });

        $('#form-order').on('submit', function(e) {
            var jumlah = $('#jumlah').val();
            if (jumlah <= 0) {
                alert('Stok harus lebih dari 0!')
                return false;
            }
        })
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\content-management-system\resources\views/admin/produksi/produksi/detail.blade.php ENDPATH**/ ?>