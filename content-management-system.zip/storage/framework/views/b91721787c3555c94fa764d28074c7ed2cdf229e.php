

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="content-header">
    <h1>
        Transaksi Bahan Baku
        <small> Transaksi bahan baku</small>
    </h1>
    <ol class="breadcrumb">
        <li><i class="fa fa-bars"></i>  Transaksi bahan baku</li>
    </ol>
</section>
<section class="content">
    <div class="box box-default">
        
        <div class="box-body">
            <?php if(auth()->user()->role == 'supplier'): ?>
            <?php endif; ?>
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active"><a href="#tab_1" data-toggle="tab">Pending</a></li>
                    <li><a href="#tab_2" data-toggle="tab">Final</a></li>

                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="tab_1">
                        <form action="<?php echo e(route('incoming-raw-material.create')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-flat bg-olive" style="margin-bottom: 15px">TAMBAH</button>
                        </form>
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Tanggal</th>
                                        <th>Dibuat oleh</th>
                                        <th>Tipe</th>
                                        
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 0; ?>
                                    <?php $__currentLoopData = $transaksi->where('status', 'pending')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$no); ?></td>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td><?php echo e($item->user->name); ?></td>
                                        <td><?php echo e($item->tipe); ?></td>
                                        
                                        <td> <a href="<?php echo e(route('incoming-raw-material.show', $item->id)); ?>" class="btn btn-flat bg-green btn-sm"> <i class="fa fa-eye"></i> </a> </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Tanggal</th>
                                        <th>Dibuat oleh</th>
                                        <th>Tipe</th>
                                        
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>

                    <div class="tab-pane" id="tab_2">
                        <div class="table-responsive">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Tipe</th>
                                        <th>Tanggal</th>
                                        <th>Dibuat oleh</th>
                                        
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $no = 0; ?>
                                    <?php $__currentLoopData = $transaksi->where('status', 'final')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(++$no); ?></td>
                                        <td> <span class="badge <?php echo e($item->tipe == 'keluar' ? 'bg-red' : 'bg-green'); ?>"><?php echo e($item->tipe); ?></span> </td>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td><?php echo e($item->user->name); ?></td>
                                        
                                        <td> <a href="<?php echo e(route('incoming-raw-material.show', $item->id)); ?>" class="btn btn-flat bg-green btn-sm"> <i class="fa fa-eye"></i> </a> </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Tipe</th>
                                        <th>Tanggal</th>
                                        <th>Dibuat oleh</th>
                                        
                                        
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>



                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<script>
    $(function() {
        $('#example1').DataTable()
        $('#example2').DataTable({
            'paging': true
            , 'lengthChange': false
            , 'searching': false
            , 'ordering': true
            , 'info': true
            , 'autoWidth': false
        })
    })

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\content-management-system\resources\views/admin/bahan-baku-masuk/index.blade.php ENDPATH**/ ?>